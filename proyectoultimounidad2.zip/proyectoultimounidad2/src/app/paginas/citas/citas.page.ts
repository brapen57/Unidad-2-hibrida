import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { Cita, CitasService } from '../../servicios/citas.service'
import { IonButton, IonLabel,IonInput, IonFooter, IonItem, IonList, IonHeader, IonToolbar, IonTitle, IonContent } from '@ionic/angular/standalone';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { FormsModule, NgForm } from '@angular/forms';


@Component({
  selector: 'app-citas',
  templateUrl: './citas.page.html',
  styleUrls: ['./citas.page.scss'],
  standalone: true,
  imports: [FormsModule, CommonModule, IonFooter, IonInput, IonLabel, IonHeader, IonToolbar, IonTitle, IonContent,IonList,IonItem, IonButton]
  
})
export class CitasPage implements OnInit {
  @Output() nuevaCitaAgregada = new EventEmitter<Cita>();

  citaActual: any;
  citas: Cita[] = [];
  nuevaCita: Cita = { texto: '', autor: '' };

  constructor(private citasService: CitasService, private router: Router) {}

  ngOnInit(): void {
    this.cargarCitas();
    this.generarCitaAleatoria();
  }

  cargarCitas(): void {
    this.citas = this.citasService.getCitas();
  }

  generarCitaAleatoria(): void {
    const citas = this.citasService.getCitas();
    if (citas.length > 0) {
      const citaAleatoria = citas[Math.floor(Math.random() * citas.length)];
      this.citaActual = citaAleatoria;
    } else {
      
      console.error('No hay citas disponibles para mostrar.');
    }
  }

  agregarCita(form: NgForm): void {
    if (form.valid) {
      this.citasService.addCita(this.nuevaCita);
      this.nuevaCitaAgregada.emit(this.nuevaCita);
      this.nuevaCita = { texto: '', autor: '' }; 
      this.cargarCitas(); 
      this.generarCitaAleatoria();
    } else {
      
      console.error('Ingrese texto y autor para agregar una nueva cita.');
      if (form.controls['autor'].hasError('minlength')) {
        console.error('El nombre del autor debe tener al menos 2 caracteres.');
      }
    }
  }

  eliminarCita(index: number): void {
    this.citasService.removeCita(index);
    this.cargarCitas(); 
  }

  navigateToHome(): void {
    this.router.navigate(['/home']);
  }

  navigateToConfiguracion(): void {
    this.router.navigate(['/configuracion']);
  }
}



