import { Component, OnInit, Input} from '@angular/core';
import { IonButton, IonLabel, IonCheckbox , IonItem, IonList, IonHeader, IonToolbar, IonTitle, IonContent } from '@ionic/angular/standalone';
import { NgModel } from '@angular/forms/';
import { FormsModule } from '@angular/forms';
import { PluginRegistry } from '@capacitor/core';

import { Plugins } from '@capacitor/core';
import { Router } from '@angular/router';
import { Preferences } from '@capacitor/preferences';

@Component({
  selector: 'app-configuracion',
  templateUrl: './configuracion.page.html',
  styleUrls: ['./configuracion.page.scss'],
  standalone: true,
  imports: [FormsModule, IonButton, IonLabel, IonCheckbox , IonItem, IonList, IonHeader, IonToolbar, IonTitle, IonContent]
})
export class ConfiguracionPage implements OnInit {
  borrarEnInicio: boolean = false;

  constructor(private router: Router) {}

  ngOnInit(): void {
    this.loadPreferences();
  }

  ionViewWillEnter() {
    this.loadPreferences();
  }

  async loadPreferences() {
    try {
      const value = await Preferences.get({ key: 'borrarEnInicio' });
      this.borrarEnInicio = value.value === 'true';
    } catch (error) {
      console.error('Error al cargar preferencias:', error);
    }
  }

  onChangeBorrarEnInicio(event: CustomEvent): void {
    this.borrarEnInicio = event.detail.checked;
    console.log('¿Desea poder borrar citas en el inicio?', this.borrarEnInicio);
    this.savePreferences();
  }

  async savePreferences() {
    try {
      if (this.borrarEnInicio) {
        await Preferences.set({ key: 'borrarEnInicio', value: 'true' });
      } else {
        await Preferences.set({ key: 'borrarEnInicio', value: 'false' });
      }
    } catch (error) {
      console.error('Error al guardar preferencias:', error);
    }
  }

  navigateToHome(): void {
    this.router.navigate(['/home']);
  }

  navigateToCitas(): void {
    this.router.navigate(['/citas']);
  }
}