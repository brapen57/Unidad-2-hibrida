import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';
import { CitasPage } from '../paginas/citas/citas.page';
import { ConfiguracionPage } from '../paginas/configuracion/configuracion.page';
import { Cita, CitasService } from '../servicios/citas.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-home',
  templateUrl: './home.page.html',
  styleUrls: ['./home.page.scss'],
  standalone: true,
  imports:[CommonModule, FormsModule, IonicModule, ConfiguracionPage ]
})
export class HomePage implements OnInit {

generateRandomQuote() {
throw new Error('Method not implemented.');
}
  citaActual: Cita = { texto: '', autor: '' };

  
    constructor(private citasService: CitasService, private router: Router) {}
  

  ngOnInit(): void {
    this.generarCitaAleatoria();
  }

  generarCitaAleatoria(): void {
    const citas = this.citasService.getCitas();
    const citaAleatoria = citas[Math.floor(Math.random() * citas.length)];
    this.citaActual = citaAleatoria;
  }

  navigateToCitas(): void {
    this.router.navigate(['/citas']);
  }
  navigateToConfiguracion(): void {
    this.router.navigate(['/configuracion']);
  }
  handleNuevaCita(nuevaCita: Cita): void {
    console.log('Nueva cita recibida:', nuevaCita);
    this.citaActual = nuevaCita;
  }
}

