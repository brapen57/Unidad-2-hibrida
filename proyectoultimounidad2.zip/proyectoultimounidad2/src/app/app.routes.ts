import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomePage } from './home/home.page';
import { CitasPage } from './paginas/citas/citas.page';
import { ConfiguracionPage } from './paginas/configuracion/configuracion.page';
import { IonicModule } from '@ionic/angular';

import { CitasService } from './servicios/citas.service';

export const routes: Routes = [
  { path: '', redirectTo: '/home', pathMatch: 'full' },
  { path: 'home', component: HomePage },
  { path: 'citas', component: CitasPage },
  { path: 'configuracion', component: ConfiguracionPage },
];

@NgModule({
  imports: [
    IonicModule.forRoot(),
    RouterModule.forRoot(routes),
  ],
    
 
})
export class AppRoutes {}