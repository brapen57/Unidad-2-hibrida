import { Injectable } from '@angular/core';

export interface Cita {
  texto: string;
  autor: string;
}

@Injectable({
  providedIn: 'root',
})
export class CitasService {
  private citas: Cita[] = [
    { texto: 'La libertad no es más que la oportunidad de ser mejor.', autor: 'Albert Camus' },
    { texto: 'La única cosa que tenemos que temer es el miedo mismo.', autor: 'Franklin D. Roosevelt' },
    { texto: 'No hay viento favorable para el marinero que no sabe a qué puerto se dirige.', autor: 'Seneca'}
    // Agrega más citas según sea necesario
  ];

  getCitas(): Cita[] {
    return this.citas;
  }

  addCita(cita: Cita): void {
    this.citas.push(cita);
  }

  removeCita(index: number): void {
    this.citas.splice(index, 1);
  }
}